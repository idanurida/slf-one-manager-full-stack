// FILE: src/hooks/use-toast.js
// Re-export dari components/ui/use-toast untuk backward compatibility
export { useToast, toast } from "@/components/ui/use-toast";

// FILE: src/pages/reports.js atau halaman lainnya
import ProjectReports from '@/components/ProjectReports';

export default function ReportsPage() {
  return (
    <div>
      <ProjectReports />
    </div>
  );
}

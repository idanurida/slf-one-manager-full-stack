
-- Verify if the profile exists
SELECT * FROM profiles WHERE email = 'ida.nuridasw@gmail.com';

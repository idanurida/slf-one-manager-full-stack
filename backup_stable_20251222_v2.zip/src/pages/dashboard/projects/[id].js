﻿export default function ProjectDetail() {
  return <div className="p-6"><h1>Project Details</h1></div>;
}
